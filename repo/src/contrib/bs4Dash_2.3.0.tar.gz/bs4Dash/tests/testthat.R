library(testthat)
library(bs4Dash)

test_check("bs4Dash")
