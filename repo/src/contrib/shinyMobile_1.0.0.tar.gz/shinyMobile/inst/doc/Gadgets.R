## ---- eval = FALSE------------------------------------------------------------
#  library(shiny)
#  library(shinyMobile)
#  runGadget(shinyAppDir(system.file("examples/tab_layout", package = "shinyMobile")))

