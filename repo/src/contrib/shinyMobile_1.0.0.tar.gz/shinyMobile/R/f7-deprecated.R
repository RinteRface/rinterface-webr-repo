#' Deprecated functions
#'
#'@rdname f7-deprecated

