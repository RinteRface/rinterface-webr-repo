library(testthat)
library(shiny.react)

test_check("shiny.react")
