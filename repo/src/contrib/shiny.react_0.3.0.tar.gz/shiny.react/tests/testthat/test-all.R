library(mockery)

test_that("mock test", {
  expect_equal("a", "a")
})
