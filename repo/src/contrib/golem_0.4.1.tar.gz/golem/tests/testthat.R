library(testthat)
library(golem)

test_check("golem")
