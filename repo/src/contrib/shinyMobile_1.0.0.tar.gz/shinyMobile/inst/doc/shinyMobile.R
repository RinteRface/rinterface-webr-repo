## ----echo=FALSE---------------------------------------------------------------
knitr::include_url("https://rinterface.com/shiny/talks/rencontresR2021/slides.html")

